import { dateFormat } from 'pub-app/helpers/date-format';
import { module, test } from 'qunit';

module('Unit | Helper | date format');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = dateFormat([42]);
  assert.ok(result);
});
