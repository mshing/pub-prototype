import { priceFormat } from 'pub-app/helpers/price-format';
import { module, test } from 'qunit';

module('Unit | Helper | price format');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = priceFormat([42]);
  assert.ok(result);
});
