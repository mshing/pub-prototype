﻿#build instructions 

npm install -g 

ember-cli npm install -g bower
